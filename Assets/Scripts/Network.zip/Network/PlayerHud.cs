using UnityEngine;

namespace HagenDa.Networking
{
    /// <summary>
    /// Client-side HUD (PHASE4 + PHASE5), drawn with IMGUI using percentage-based
    /// sizing (all positions/sizes derive from Screen width/height fractions, no pixel
    /// constants). Shows:
    ///   - a white crosshair at screen center that widens with weapon bloom,
    ///   - a white "X" hitmarker (hollow center) for 2 rendered frames after a hit,
    ///   - a bottom-center health bar (white fill, black for missing health),
    ///   - the current armor as a number right of the bar (hidden when 0),
    ///   - the current magazine / reserve ammo, fire mode, and reload state.
    /// </summary>
    public class PlayerHud : MonoBehaviour
    {
        public NetworkPlayerHealth health;

        private NetworkPlayerController controller;
        private NetworkGun gun;
        private int hitmarkerEndFrame = -1;

        private Texture2D whiteTex;
        private Texture2D blackTex;
        private GUIStyle armorStyle;
        private GUIStyle ammoStyle;
        private GUIStyle modeStyle;

        private void Awake()
        {
            controller = GetComponent<NetworkPlayerController>();
            if (health == null) health = GetComponent<NetworkPlayerHealth>();
            gun = GetComponent<NetworkGun>();
        }

        private void OnEnable()
        {
            if (whiteTex == null) whiteTex = MakeSolidTexture(Color.white);
            if (blackTex == null) blackTex = MakeSolidTexture(Color.black);
        }

        /// <summary>Show the hitmarker for 2 rendered frames.</summary>
        public void ShowHitmarker()
        {
            hitmarkerEndFrame = Time.frameCount + 2;
        }

        private void OnGUI()
        {
            if (controller == null || !controller.isLocalPlayer) return;
            if (health == null) return;

            DrawCrosshair();
            DrawHitmarker();
            DrawHealthBar();
            DrawArmor();
            DrawAmmo();
        }

        // ---------------------------------------------------------------
        // CROSSHAIR (spread widens the gap)
        // ---------------------------------------------------------------
        private void DrawCrosshair()
        {
            float cx = Screen.width * 0.5f;
            float cy = Screen.height * 0.5f;
            float len = Screen.height * 0.012f;
            float thick = Mathf.Max(2f, Screen.height * 0.004f);

            // Bloom (degrees) widens the crosshair gap. Full bloom (10°) maps to a
            // clearly open crosshair; aimed (0.1°) collapses to a tight center.
            float bloom = gun != null ? gun.bloom : 0f;
            float gap = Screen.height * (0.005f + bloom * 0.004f);

            DrawLine(new Vector2(cx, cy - gap - len), new Vector2(cx, cy - gap), thick);
            DrawLine(new Vector2(cx, cy + gap), new Vector2(cx, cy + gap + len), thick);
            DrawLine(new Vector2(cx - gap - len, cy), new Vector2(cx - gap, cy), thick);
            DrawLine(new Vector2(cx + gap, cy), new Vector2(cx + gap + len, cy), thick);
        }

        // ---------------------------------------------------------------
        // HITMARKER (white X, hollow center)
        // ---------------------------------------------------------------
        private void DrawHitmarker()
        {
            if (Time.frameCount >= hitmarkerEndFrame) return;

            float cx = Screen.width * 0.5f;
            float cy = Screen.height * 0.5f;
            float len = Screen.height * 0.018f;
            float thick = Mathf.Max(1f, Screen.height * 0.002f);
            float gap = Screen.height * 0.008f;

            Vector2 c = new Vector2(cx, cy);
            float k = 0.70710678f;   // 1/sqrt(2)
            Vector2[] dirs =
            {
                new Vector2(k, k), new Vector2(k, -k),
                new Vector2(-k, -k), new Vector2(-k, k)
            };

            foreach (var d in dirs)
            {
                DrawLine(c + d * gap, c + d * (gap + len), thick);
            }
        }

        // ---------------------------------------------------------------
        // HEALTH BAR (bottom center: white fill, black missing)
        // ---------------------------------------------------------------
        private void DrawHealthBar()
        {
            float barW = Screen.width * 0.3f;
            float barH = Screen.height * 0.025f;
            float x = (Screen.width - barW) * 0.5f;
            float y = Screen.height * 0.93f;

            GUI.DrawTexture(new Rect(x, y, barW, barH), blackTex);

            float frac = Mathf.Clamp01(health.health / Mathf.Max(0.001f, health.maxHealth));
            GUI.DrawTexture(new Rect(x, y, barW * frac, barH), whiteTex);
        }

        // ---------------------------------------------------------------
        // ARMOR (number right of bar, hidden when 0)
        // ---------------------------------------------------------------
        private void DrawArmor()
        {
            if (health.armor <= 0f) return;

            float barW = Screen.width * 0.3f;
            float barH = Screen.height * 0.025f;
            float x = (Screen.width - barW) * 0.5f;
            float y = Screen.height * 0.93f;

            if (armorStyle == null)
            {
                armorStyle = new GUIStyle(GUI.skin.label);
                armorStyle.fontSize = Mathf.Max(12, Mathf.RoundToInt(Screen.height * 0.03f));
                armorStyle.normal.textColor = Color.white;
                armorStyle.alignment = TextAnchor.MiddleLeft;
                armorStyle.clipping = TextClipping.Overflow; // don't clip text taller than the rect
            }

            string text = Mathf.RoundToInt(health.armor).ToString();
            float tx = x + barW + Screen.width * 0.01f;
            float armorH = Screen.height * 0.035f; // room for the full glyph height
            GUI.Label(new Rect(tx, y, Screen.width * 0.15f, armorH), text, armorStyle);
        }

        // ---------------------------------------------------------------
        // AMMO / FIRE MODE / RELOAD (bottom right)
        // ---------------------------------------------------------------
        private void DrawAmmo()
        {
            if (gun == null || gun.Definition == null) return;

            float y = Screen.height * 0.93f;
            float x = Screen.width * 0.82f;
            float h = Screen.height * 0.03f;

            if (ammoStyle == null)
            {
                ammoStyle = new GUIStyle(GUI.skin.label);
                ammoStyle.fontSize = Mathf.Max(14, Mathf.RoundToInt(Screen.height * 0.032f));
                ammoStyle.normal.textColor = Color.white;
                ammoStyle.alignment = TextAnchor.MiddleRight;
                ammoStyle.clipping = TextClipping.Overflow; // don't clip text taller than the rect
                ApplyCjkFont(ammoStyle);
            }

            string ammoText = $"{gun.magAmmo} / {gun.reserveAmmo}";
            if (gun.reloading)
            {
                ammoText += gun.reloadPaused ? "  (换弹暂停)" : "  (换弹中...)";
            }
            GUI.Label(new Rect(x, y, Screen.width * 0.16f, h), ammoText, ammoStyle);

            if (modeStyle == null)
            {
                modeStyle = new GUIStyle(GUI.skin.label);
                modeStyle.fontSize = Mathf.Max(12, Mathf.RoundToInt(Screen.height * 0.022f));
                modeStyle.normal.textColor = Color.white;
                modeStyle.alignment = TextAnchor.MiddleRight;
                modeStyle.clipping = TextClipping.Overflow; // don't clip text taller than the rect
                ApplyCjkFont(modeStyle);
            }

            string mode = FireModeLabel();
            GUI.Label(new Rect(x, y - h, Screen.width * 0.16f, h), mode, modeStyle);
        }

        private string FireModeLabel()
        {
            var modes = gun.Definition.fireModes;
            if (modes == null || modes.Count == 0) return "";
            int idx = ((gun.fireModeIndex % modes.Count) + modes.Count) % modes.Count;
            switch (modes[idx])
            {
                case FireMode.Semi: return "半自动";
                case FireMode.Burst: return "连射";
                case FireMode.Bolt: return "栓动";
                default: return "全自动";
            }
        }

        // ---------------------------------------------------------------
        // HELPERS
        // ---------------------------------------------------------------
        private void DrawLine(Vector2 a, Vector2 b, float thickness)
        {
            Vector2 delta = b - a;
            float len = delta.magnitude;
            if (len <= 0f) return;

            float angle = Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg;

            var oldMatrix = GUI.matrix;
            GUIUtility.RotateAroundPivot(angle, a);
            GUI.DrawTexture(new Rect(a.x, a.y - thickness * 0.5f, len, thickness), whiteTex);
            GUI.matrix = oldMatrix;
        }

        private static Texture2D MakeSolidTexture(Color color)
        {
            var tex = new Texture2D(1, 1);
            tex.SetPixel(0, 0, color);
            tex.Apply();
            return tex;
        }

        // IMGUI's default font has no CJK glyphs; use a dynamic OS font for the
        // Chinese ammo/mode labels.
        private static void ApplyCjkFont(GUIStyle style)
        {
            Font cjk = Font.CreateDynamicFontFromOSFont("Microsoft YaHei", style.fontSize);
            if (cjk != null)
                style.font = cjk;
        }
    }
}
